
import java.util.*;
import java.io.*;
/**
 * <<< GENETIC ARITHMETIC! >>>
v.1.2
author: v.i.
A simple genetic programming example. 
Enter a real 'target' number...                           
And watch the magic! 8^)                                          

GOAL: Solve the problem of approximating a real number using a predetermined number of non-trivial arithmetic operations,
utilizing genetic programming.

PRINCIPLES: 
This algorithm generates "i" arithmetic calculations, starting at 1.
4 operations exist: +e, -e , *Pi, /Pi, uniquely encoded in a string of length "i". That string is then a 'specimen'.
Operation encoding: +e ==> 0, -e ==> 1, *Pi ==> 2, /Pi ==> 3
Each generation, "n" specimen are created from random permutations on <="m" random characters of ancestor string,
and the best one (closest to target) is selected to father the subsequent generation.
Process terminated when target reached within reasonable tolerance (<k), or else when z generations have elapsed
 * 
 * @author Victor Ivri (vi1985)
 */
public class mainClass
{
	protected static double target;
	protected static double tolerance;

	/**
	 * @param args
	 */
	public static void main(String[] args) 
	{
		Scanner in = new Scanner(System.in);
//		setting up:
		initial();
		System.out.print("Enter the target number now: ");
		target = in.nextDouble();
		System.out.print("Enter the desired generation size: ");
		int genSize = in.nextInt();
		System.out.print("Enter the desired size of the individual: ");
		int indSize = in.nextInt();
		System.out.print("Enter the desired amount of genetic mutation (1 -> individual_size - 1): ");
		int mutation = in.nextInt();
		System.out.print("The deviation tolerance to enforce: ");
		tolerance = in.nextDouble();
		System.out.print("If solution not found, after how many generations to terminate?: ");
		int terminate = in.nextInt();

		
//		initializing process:
		boolean found = false; //found!
		Generation first = new Generation(genSize, mutation, indSize);
		int count = 1; //generation count
		System.out.print(count);
		first.print();
		found = first.terminate;
		
		Specimen ancestor = first.bestOne;
//		iterating:
		while (!found)
		{
			count++;
			Generation next = new Generation(ancestor, genSize, mutation, indSize);
			System.out.print(count);
			next.print();
			found = next.terminate; //checking if it's the result
			ancestor = next.bestOne; //setting the ancestor for next gen.
			
			if (count > terminate - 1)
			{
				System.out.print("SOLUTION NOT FOUND IN " + terminate + " GENERATIONS... TERMINATING");
				return;
			}
		}
		
//displaying accepted arithmetic expression:
		minimize(ancestor);
	}
	
	private static void initial()
	{
		PrintStream out = System.out;
		String s = "<<< GENETIC ARITHMETIC! >>> \nv.1.2 \nauthor: v.i. \nA simple genetic programming example. \nEnter a real 'target' number... \n" +
				"And watch the magic! 8^) \nGOAL: Solve the problem of approximating a real number \nusing a predetermined number of non-trivial " +
				"arithmetic operations, utilizing genetic programming.";
	
			for (int i = 0; i < s.length(); i++)
			{
				long now = System.currentTimeMillis();
				while (!timer(now)){/*do nothing*/}
				out.print(s.charAt(i));	
			}
			out.print("\n");
	}

	//helper method for initial(). a very simple time-comparator
	private static boolean timer(long now)
	{
		boolean go = false;
		if (System.currentTimeMillis() - now > 1)
			go = true;

		return go;
	}
	
	private static void displayComputation(String s, double value)
	{
		PrintStream out = System.out;
		out.println("The final computation is as follows:");
		out.print("1");
		
		for(int i = 0; i < s.length(); i++)
		{
			if (s.substring(i, i + 1).equals("0"))
				out.print(" + e");
			else if (s.substring(i, i + 1).equals("1"))
				out.print(" - e");
			else if (s.substring(i, i + 1).equals("2"))
				out.print(" * Pi");
			else if (s.substring(i, i + 1).equals("3"))
				out.print(" / Pi");
		}
		out.println(" = " + value);
		double deviation = Math.abs(target - value);
		out.println("The target: " + target + "    Deviation: " + deviation);
		out.println("**Note the arithmetic operations occur in sequence left to right, so: \n" +
				"a + b / c is: (a + b) / c, and not a + (b / c).");
	}

	
	public static void minimize(Specimen solution) //a minimization algorithm: gets rid of redundant pairs of arithmetic operations
	{
		String newSolution = new String(solution.getSpecimen());
		boolean terminate = false;
		while (!terminate)
		{
			String oldString = new String(newSolution);
			newSolution = solution.getSpecimen().replaceAll("10", "");	
			newSolution = newSolution.replaceAll("01", "");
			newSolution = newSolution.replaceAll("23", "");
			newSolution = newSolution.replaceAll("32", "");
		
			if (oldString.equals(newSolution))
				terminate = true;
		}
		
		System.out.println("\nMinimized version:");
		System.out.print(newSolution);
		int difference = solution.getSpecimen().length() - newSolution.length();
		System.out.print("		(Length difference: " + difference + " )\n");
		
		displayComputation(newSolution, solution.value);
		
	}
}
