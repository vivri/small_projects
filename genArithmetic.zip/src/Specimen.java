import java.util.Random;


//A specimen, in string form of length n, of an arithmetic manipulation sequence,
//starting at 1. Operations (and their string-coding) are:
// +e ==> 0, -e ==> 1, *Pi ==> 2, /Pi ==> 3 

public class Specimen
{
	public String Specimen; //the string that represents the individual
	private int size; //the size of the specimen in question
	public double value; //the numeric value of this specimen
	
	public Specimen(int indSize) //generate a random specimen
	{
		size = indSize;
		Specimen = this.makeRandom();
		value = this.getValue();
	}
	
	public Specimen (Specimen other, int mutations, int indSize) //mutate another specimen
	{
		size = indSize;
		Specimen = evolve(other, mutations);
		value = this.getValue();
	}
	
	//Creates a new random Specimen
	private String makeRandom()
	{
		String randSpec = "";
				
		for (int i = 0; i < size; i++)
			randSpec = randSpec + randChar();
		
		return randSpec;
	}
	
	private String evolve(Specimen other, int mutations) //makes random changes in <n random locations
	{
		char[] charArray = other.getSpecimen().toCharArray();
		Random r = new Random();
		
		for (int i = 0; i < mutations; i++) //DO n times: Put a random char at a random location in the string
		{
			int place = r.nextInt(size);
			charArray[place] = Integer.toString(randChar()).charAt(0); 
		}
		
		String newSpecimen = new String(charArray);
		return newSpecimen;
		
	}
	
	private int randChar() // a random integer generator in range 0-3
	{
		int randChar;   
		double rand = Math.random();
		if (rand < .25)
			randChar = 0;
		else if(rand <.5)
			randChar = 1;
		else if(rand <.75)
			randChar = 2;
		else
			randChar = 3;
		
		return randChar;
	}
	
	
	//Returns string representation of specimen
	public String getSpecimen()
	{
		return new String(this.Specimen);
	}
	
	//Returns the numeric value of the specimen
	private double getValue()
	{
		assert Specimen.length() == size; // should always be true!
		
		double value = 1;
		for (int i = 0; i < size; i++)
		{
			int ch = Integer.parseInt(Character.toString(Specimen.charAt(i)));
			if (ch == 0)
				value = value + Math.E;
			else if (ch == 1)
				value = value - Math.E;
			else if (ch == 2)
				value = value * Math.PI;
			else 
				value = value / Math.PI;
		}
		
		return value;
	}


}












