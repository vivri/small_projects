
//A class with static methods to evaluate the fitness of individual specimen.
public class Fitness
{
	private Fitness(){/*dummy constructor*/}
	
	//evaluates closeness to target. SMALL IS BETTER
	public static double closeness(double targ, double spec)
	{
		return Math.abs(targ - spec);
	}
	
	//returns true if the specimen is close enough to target, for the process to terminate
	public static boolean closeEnough(double targ, double spec)
	{
		return closeness(targ, spec) < mainClass.tolerance;
	}
}
