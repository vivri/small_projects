public class Generation
{
	Specimen ancestor; //the ancestor of the entire generation
	int genSize; //the size of the generation
	Specimen[] children; //size of each generation
	Specimen bestOne = null;
	boolean terminate = false; //becomes true when the best specimen is close enough to the target
	
	public Generation(int generationSize, int mutations, int indSize) // for the first time
	{
		ancestor = new Specimen(indSize);
		genSize = generationSize;
		children = new Specimen[genSize];
		for (int i = 0; i < genSize; i++)
			children[i] = null;
		
		init(mutations, indSize); 
	}
	
	public Generation(Specimen ancest, int generationSize, int mutations, int indSize)
	{
		ancestor = ancest;
		genSize = generationSize;
		children = new Specimen[genSize];
		for (int i = 0; i < genSize; i++)
			children[i] = null;
		init(mutations, indSize); 
	}
	//initializes
	private void init(int mutations, int indSize)
	{
		Specimen best = null; //the best one in its generation
		
		for (int i = 0; i < genSize; i++) //populate the generation with mutated specimen
			children[i] = new Specimen(ancestor, mutations, indSize);
			
		best = children[0];  //determine the fittest of the generation
		for (int i = 1; i < genSize; i++)
			if (Fitness.closeness(mainClass.target, best.value) > Fitness.closeness(mainClass.target, children[i].value))
				best = children[i];
		
		bestOne = best;
		if (Fitness.closeEnough(mainClass.target, best.value))
			terminate = true;
	}
	
	public void print()
	{
		System.out.println(" - generation:");
		System.out.println("Best specimen: " + bestOne.getSpecimen() + "    Value: " + bestOne.value + 
							"    Deviation: " + Math.abs(bestOne.value - mainClass.target));
	}
	
	
	

}