<<< GENETIC ARITHMETIC! >>>
v.1.2
author: v.i.
A simple genetic programming example. 
Enter a real 'target' number...                           
And watch the magic! 8^)                                          

GOAL: Solve the problem of approximating a real number using a predetermined number of non-trivial arithmetic operations,
utilizing genetic programming.

PRINCIPLES: 
This algorithm generates "i" arithmetic calculations, starting at 1.
4 operations exist: +e, -e , *Pi, /Pi, uniquely encoded in a string of length "i". That string is then a 'specimen'.
Operation encoding: +e ==> 0, -e ==> 1, *Pi ==> 2, /Pi ==> 3
Each generation, "n" specimen are created from random permutations on <="m" random characters of ancestor string,
and the best one (closest to target) is selected to father the subsequent generation.
Process terminated when target reached within reasonable tolerance (<k), or else when z generations have elapsed

INSTRUCTIONS: 
1) COMPILE
2) RUN mainClass.class
3) ENJOY
